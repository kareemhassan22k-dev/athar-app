package com.athar.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AtharApp() }
    }
}

@Composable
fun AtharApp() {
    var screen by remember { mutableStateOf("splash") }
    LaunchedEffect(Unit) { delay(1400); screen = "welcome" }
    MaterialTheme {
        when (screen) {
            "splash" -> SplashScreen()
            "welcome" -> WelcomeScreen { screen = "chat" }
            else -> ChatScreen()
        }
    }
}

@Composable
fun SplashScreen() {
    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            Text("أثر", fontSize = 52.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text("مش بس يجاوبك... يكمل معاك.", fontSize = 18.sp)
        }
    }
}

@Composable
fun WelcomeScreen(onStart: () -> Unit) {
    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            Text("أهلًا بيك في أثر 👋", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            Text("أنا هنا عشان أساعدك، أفتكر المهم، وأكمل معاك.", fontSize = 17.sp)
            Spacer(Modifier.height(34.dp))
            Button(onClick = onStart, shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth().height(54.dp)) {
                Text("ابدأ مع أثر", fontSize = 17.sp)
            }
        }
    }
}

@Composable
fun ChatScreen() {
    var message by remember { mutableStateOf("") }
    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("أثر", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("⚡")
            }
            Column(Modifier.weight(1f).fillMaxWidth().padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center) {
                Text("أهلًا 👋", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("إيه اللي نقدر نعمله النهارده؟")
            }
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {}) { Text("＋", fontSize = 24.sp) }
                OutlinedTextField(value = message, onValueChange = { message = it },
                    modifier = Modifier.weight(1f), placeholder = { Text("اكتب لأثر...") },
                    shape = RoundedCornerShape(22.dp), singleLine = false)
                IconButton(onClick = {}) { Text("🎙️") }
                IconButton(onClick = {}) { Text("➤", fontSize = 22.sp) }
            }
        }
    }
}
